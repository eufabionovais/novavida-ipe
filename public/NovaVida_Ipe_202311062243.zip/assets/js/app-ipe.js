gsap.registerPlugin(ScrollTrigger);

$(function () {
  // Gerencia Status de visibilidade do menu principal
  $("body").attr("data-collapse", false);
  $("[data-toggle-menu]").on("click", function () {
    if ($("body").data("collapse") == false) {
      $("body").data("collapse", true);
      $("body").attr("data-collapse", true);
    } else {
      $("body").data("collapse", false);
      $("body").attr("data-collapse", false);
    }
  });

  $(window).on("resize", function () {
    let windowSize = $(this).width();
    if (windowSize <= 1200) {
      $("body").data("collapse", true);
      $("body").attr("data-collapse", true);
    } else {
      $("body").data("collapse", false);
      $("body").attr("data-collapse", false);
    }
  });

  $(window).trigger("resize");

  // Gerencia Status de visibilidade do menu principal

  // Exibição de Menu na versão mobile
  $(".main-nav__link")
    .on("mouseover", function () {
      if (!$(".tooltip-menu").length) {
        $("<div class='tooltip-menu'></div>").appendTo(".main__wrapper");
      }
      const positionTop = $(this).offset().top;
      const elementWidth = $(".sidebar").width();
      const text = $(this).find(".main-nav__link-text").text();
      $(".tooltip-menu").html(text);

      $(".tooltip-menu").offset({ top: positionTop, left: elementWidth + 30 });
    })
    .on("mouseout", function () {
      $(".tooltip-menu").remove();
    });
  // Exibição de Menu na versão mobile

  // Exibição do botão para mostrar/ocultar senha
  $(":password").each(function () {
    $(this)
      .parents(".password-wrapper")
      .append(
        "<button class='toggle-password'><span class='material-symbols-outlined'>visibility</span ></button>",
      );
  });

  $(".toggle-password").on("click", function (e) {
    e.preventDefault();
    if ($(this).find("span").html() == "visibility") {
      $(this).find("span").html("visibility_off");
      $(this).siblings(":input").attr("type", "text");
    } else {
      $(this).find("span").html("visibility");
      $(this).siblings(":input").attr("type", "password");
    }
  });
  // Exibição do botão para mostrar/ocultar senha

  // Habilitar máscara para CPF/CNPJ simultâneamente.
  if ($("[data-mask='cpf-cnpj']").length) {
    $("[data-mask='cpf-cnpj']").mask("000.000.000-00", {
      onKeyPress: function (cpfcnpj, e, field, options) {
        const masks = ["000.000.000-000", "00.000.000/0000-00"];
        const mask = cpfcnpj.length > 14 ? masks[1] : masks[0];
        $("[data-mask='cpf-cnpj']").mask(mask, options);
      },
    });
  }
  // Habilitar máscara para CPF/CNPJ simultâneamente.

  if ($("#enriquecimentosTbl").length) {
    let table = new DataTable("#enriquecimentosTbl", {
      paging: false,
      searching: false,
      info: false,
      columns: [
        { orderable: false },
        { orderable: false, width: "25%" },
        { orderable: false },
        { orderable: false },
        { orderable: true },
        { orderable: false },
        { orderable: false, width: "150px", className: "text--center" },
      ],
    });

    $("#enriquecimentosTbl").on("click", "a", function () {
      contentGridContainer.addClass("opened");
    });
  }

  if ($("#estudosTbl").length) {
    let table = new DataTable("#estudosTbl", {
      paging: false,
      searching: false,
      info: false,
      columns: [
        { orderable: false },
        { orderable: false },
        { orderable: false, width: "25%" },
        { orderable: false },
        { orderable: true },
        { orderable: false },
        { orderable: false, width: "150px", className: "text--center" },
      ],
    });

    $("#estudosTbl").on("click", "a:not(.btn-chart)", function () {
      contentGridContainer.addClass("opened");
    });
  }

  if ($("#layoutsTbl").length) {
    let table = new DataTable("#layoutsTbl", {
      paging: false,
      searching: false,
      info: false,
      columns: [
        { orderable: false },
        { orderable: false },
        { orderable: false, width: "25%" },
        { orderable: false },
        { orderable: true },
        { orderable: false },
        { orderable: false, width: "150px", className: "text--center" },
      ],
    });
  }

  if ($("#campanhasTbl").length) {
    let table = new DataTable("#campanhasTbl", {
      paging: false,
      searching: false,
      info: false,
      columns: [
        { orderable: false, width: "60%" },
        { orderable: false },
        { orderable: false },
        { orderable: false, width: "200px", className: "text--center" },
      ],
    });
  }

  if ($(".upload-file__dropzone").length) {
    $(".upload-file__dropzone").dropzone({ url: "/file/post" });
  }

  const tooltipTriggerList = document.querySelectorAll(
    '[data-bs-toggle="tooltip"]',
  );
  const tooltipList = [...tooltipTriggerList].map(
    (tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl),
  );

  const contentGridContainer = $("[data-container='content-grid-wrapper']");
  const gridSidebartoggle = $("[data-toggle='grid-sidebar']");

  $(gridSidebartoggle).on("click", function (e) {
    e.preventDefault();
    contentGridContainer.removeClass("opened");
  });

  const filtrosAvancados = $("#filtrosAvancados");
  const toggleFiltersButton = $("#toggleAdvancedSearch");

  filtrosAvancados.hide();
  toggleFiltersButton.on("click", function () {
    if (!$(this).hasClass("filtered")) {
      $(this).toggleClass("active").toggleClass("btn-primary btn-secondary");
      $(this).find(".icon").toggleClass("text-primary");
      filtrosAvancados.slideToggle();
    } else {
      $(this).addClass("active filtered");
      filtrosAvancados.slideDown();
    }
  });

  $("#saveFilteredData").on("click", function () {
    toggleFiltersButton.addClass("active filtered");
    toggleFiltersButton.find(".icon").removeClass("text-primary");
    filtrosAvancados.slideUp();
  });

  $("#resetFilters").on("click", function () {
    toggleFiltersButton
      .removeClass("active filtered")
      .removeClass("btn-primary")
      .addClass("btn-secondary");
    toggleFiltersButton.find(".icon").addClass("text-primary");
    filtrosAvancados.slideUp();
  });

  if ($(".dropdown-toggle").length) {
    $(".dropdown-toggle").dropdown();
  }

  if ($("[data-input-group]").length) {
    $("[data-input-group]").on("keyup", function () {
      let value = $(this).val();
      let valueLength = value.length;
      if (valueLength > 0) {
        $(this)
          .siblings(".input-group-text")
          .find(".btn")
          .removeAttr("disabled");
      } else {
        $(this)
          .siblings(".input-group-text")
          .find(".btn")
          .attr("disabled", true);
      }
    });
  }

  $("#btnConfirmarLayout").on("click", function () {
    $("#novoLayoutDialog").modal("hide");
    $("#confirmarLayoutDialog").modal("show");
  });

  $("#btnVoltarNovoLayout").on("click", function () {
    $("#confirmarLayoutDialog").modal("hide");
    $("#novoLayoutDialog").modal("show");
  });

  const swiperElement = document.querySelector(".swiper");
  if (swiperElement) {
    const swiper = new Swiper(swiperElement, {
      speed: 400,
      spaceBetween: 100,
      autoHeight: true,
      allowTouchMove: false,
      prevEl: ".btn-swiper-prev",
      nextEl: ".btn-swiper-next",
      on: {
        init: function () {
          checkBlockSliderButtons(this);
          hideAllCharts();
          animateCharts();
        },

        slideChange: function () {
          hideAllCharts();

          window.scrollTo({ top: 0, left: 0, behavior: "instant" });

          const currentIndex = this.realIndex;
          const slideTitulo = this.slides[currentIndex].dataset.titulo;
          $("#slideTitle").html(slideTitulo);
          animateCharts();
        },

        slideChangeTransitionEnd: function () {
          hideAllCharts();
          animateCharts();
          checkBlockSliderButtons(this);
        },
      },
    });

    function checkBlockSliderButtons(target) {
      if (target.isBeginning) {
        $(".btn-swiper-prev").attr("disabled", "disabled");
        $(".btn-swiper-next").removeAttr("disabled");
      } else if (target.isEnd) {
        $(".btn-swiper-next").attr("disabled", "disabled");
        $(".btn-swiper-prev").removeAttr("disabled");
      } else {
        $(".btn-swiper-prev, .btn-swiper-next").removeAttr("disabled");
      }
    }

    const swiperInstance = swiperElement.swiper;

    swiperInstance.on("slideChangeTransitionEnd", function () {});

    $(".btn-swiper-prev").on("click", function () {
      if (swiperInstance.isBeginning) {
        return;
      }
      swiperInstance.slidePrev();
    });

    $(".btn-swiper-next").on("click", function () {
      if (swiperInstance.isEnd) {
        return;
      }
      swiperInstance.slideNext();
    });
  }
});

function animateCharts() {
  const boxes = document.querySelectorAll(".chart-item");
  const boxesTimeline = boxes.forEach((box) => {
    boxTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: box,
        start: "top 80%",
      },
    });

    boxTimeline.to(box, { opacity: 1, y: 0, duration: 0.8 });
  });
}

function hideAllCharts() {
  const boxes = document.querySelectorAll(".chart-item");
  gsap.set(boxes, { opacity: 0, y: 50 });
}
